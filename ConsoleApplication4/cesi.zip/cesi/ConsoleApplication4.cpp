// ConsoleApplication4.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
#include"locale.h"
#include <windows.h>
#include"atlbase.h"
#include"TlHelp32.h"
#include <stdio.h>
#include <string.h>
#include <string>

#include<tchar.h>
#include<iostream>
using namespace std;
//#import "CSApplicationUp.tlb" named_guids raw_interfaces_only
#import "ClassLibrary.tlb" named_guids raw_interfaces_only
#pragma   comment(linker,   "/subsystem:\"windows\"   /entry:\"mainCRTStartup\""   ) 
int main(int argc, char * argv[])
{







	//_tsetlocale(LC_ALL, _T("chs"));
	_tprintf(_T("����: %d ��\n"), argc);



	for (int i = 1; i < argc; ++i)
	{
		printf("������� [%d] = [%s]\n", i, argv[i]);

	}
	printf("%s\n", argv[0]);//��ȡ�������� ����Ϊ0
	printf("%s\n", argv[1]);//��ȡ�����һ����������Ϊ1
	printf("%s\n", argv[2]);//��ȡ����ڶ�����������Ϊ2


	std::string strPath1 = argv[0];
	std::string strPath = argv[1];
	std::string name = strPath.substr(8, strPath.size() - 9);
	printf("%s", name.c_str());


		






	printf("%s", strPath.c_str());
	CComBSTR infa("sdf");

	CComBSTR resss("sdfgdsfgsd");
	CComBSTR res;
	CComBSTR resds;
	CComBSTR inf(name.c_str());
	CComBSTR res1(strPath1.c_str());
	const char *str1 = "off";
	const char *str2 = "off";
	CoInitialize(NULL);
	//CSApplicationUp::IMyInterfacePtr p;
	//HRESULT hs = p.CreateInstance(_uuidof(CSApplicationUp::Class1));
	ClassLibrary::IMyInterfacePtr lib;
	HRESULT hs = lib.CreateInstance(_uuidof(ClassLibrary::ConnentEDM3));


	int a = (int)hs;
	printf("%i", a);




	PROCESSENTRY32 pe32;
	pe32.dwSize = sizeof(pe32);
	HANDLE hProcessSnap = ::CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);

	if (hProcessSnap == INVALID_HANDLE_VALUE)
	{
		printf(" CreateToolhelp32Snapshot����ʧ�ܣ� \n");
	
		return 0;
	}
	
	BOOL bMore = ::Process32First(hProcessSnap, &pe32);
	while (bMore)
	{
		//printf(" �������ƣ�%f \n", pe32.szExeFile);

		_bstr_t b(pe32.szExeFile);
		const char*pe3 = b;
		if (_stricmp("EDM2.exe", pe3) == 0)
		{
			str2 = "open";
		}
		bMore = ::Process32Next(hProcessSnap, &pe32);
	}
	if (_stricmp(str1, str2) == 0) {

		lib->ConnentEDM3Res(&infa);

		lib->Send(inf, &resss);

	/*	p->ApplicationUp(res1);

		Sleep(3000);
		p->ClientWrite(&res);
		p->WriteInfo(inf, &resds);*/

		str2 = "off";


	
	}
	else
	{
	/*	p->ClientWrite(&res);
		p->WriteInfo(inf, &resds);
		CoUninitialize();
		return S_OK;*/
	}

	

	Sleep( 60 * 1000);

	



	return 0;


	

}

